package com.week14.GradedAssignmentdemo.service;


import java.util.List;

import com.week14.GradedAssignmentdemo.Model.Employee;


public interface EmployeeService {
    
 // Create operation
    void addEmployee(Employee employee);
    // Read operation
    Employee getEmployeeById(int employeeId);
    List<Employee> getAllEmployees();
    // Update operation
    void updateEmployee(Employee employee);
    // Delete operation
    void deleteEmployee(int employeeId);
}

