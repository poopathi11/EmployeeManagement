package com.week14.GradedAssignmentdemo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.week14.GradedAssignmentdemo.Model.Employee;
import com.week14.GradedAssignmentdemo.service.EmployeeService;

import java.util.List;

@Controller

public class MainController {

    @Autowired
    private EmployeeService employeeService;
    
    @RequestMapping("/")
    public String homePage() {
    	return "home";
    }

    @RequestMapping("/employee/list")
    public String listEmployees(Model model) {
        List<Employee> employees = employeeService.getAllEmployees();
        model.addAttribute("employees", employees);
        return "employee-list"; // This will resolve to employee-list.jsp
    }

    @RequestMapping("/employee/add")
    public String showFormForAdd() {
      
        return "employee-form"; // This will resolve to employee-form.jsp for adding a new employee
    }

    @PostMapping("/employee/insert")
    public String saveEmployee(@RequestParam String employeeName, @RequestParam String employeeAddress , @RequestParam String employeePhone , @RequestParam String employeeSalary,Model data) {
    	employeeService.addEmployee(new Employee(0, employeeName, employeeAddress, employeePhone, employeeSalary));
		List<Employee> employees = employeeService.getAllEmployees();
		data.addAttribute("employees",employees);
        return "employee-list"; // Redirect to the list of employees after adding
    }

    @PostMapping("/employee/update")
    public String showFormForUpdate(@RequestParam int id, Model model) {
        Employee employee = employeeService.getEmployeeById(id);
        model.addAttribute("employees", employee);
        return "update-form"; 
    }
    @PostMapping("/employee/updateEmployee")
	public String finalUpdate(@RequestParam int id,@RequestParam String employeeName, @RequestParam String employeeAddress , @RequestParam String employeePhone , @RequestParam String employeeSalary , Model  model) 
	{
    	employeeService.updateEmployee(new Employee(id, employeeName, employeeAddress, employeePhone, employeeSalary));
		List<Employee> employees = employeeService.getAllEmployees();
		model.addAttribute("employees",employees);
		return "employee-list";
	}

    @PostMapping("/employee/delete")
    public String deleteEmployee(@RequestParam int id,Model data) {
    	employeeService.deleteEmployee(id);
    	List<Employee> employees = employeeService.getAllEmployees();
        data.addAttribute("employees",employees);
        return "employee-list"; 
    }
}

